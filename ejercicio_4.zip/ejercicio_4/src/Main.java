public class Main {

    public static void main(String[] args) {
        int numeroIf = 1;

        if (numeroIf == 1) {
            System.out.println("es positivo");
        } else if (numeroIf == -1) {
            System.out.println("es negativo");
        } else {
            System.out.println("es 0");
        }
        int Contador = 0;

        while (Contador < 3) {
            System.out.println(Contador);
            Contador = Contador + 1;
        }
            do {
            System.out.println(Contador);
            Contador = Contador +1;

        }while(Contador < 1);


    }
}


