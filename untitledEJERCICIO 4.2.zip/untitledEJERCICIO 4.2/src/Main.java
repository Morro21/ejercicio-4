import org.w3c.dom.ls.LSOutput;

import javax.sound.midi.spi.SoundbankReader;
import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {

        for (int numero = 0; numero <= 3; numero = numero + 1) {

            System.out.println(numero);
        }
        var estacion = "VERANO";

        switch (estacion) {
            case "VERANO":
                System.out.println( " es verano" );
            case "INVIERNO":
                System.out.println(" es invierno");
            case "PRIMAVERA":
                System.out.println(" es primamvera");
            case "OTOÑO":
                System.out.println(" es otoño");

            default:
                System.out.println( " estoy en default");
        }
    }


}
